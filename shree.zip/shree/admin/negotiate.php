<?php
require('top.inc.php'); 

$user = $_SESSION['ADMIN_ID'];  
$sql = "select *,product.name as p_name  from negotiations join product on product.id = negotiations.product_id join users on users.id = negotiations.customer_id where product.added_by = $user";
$res=mysqli_query($con,$sql);
// echo"<pre>";print_R($sql);die;

?>
<div class="content pb-0">
	<div class="orders">
	   <div class="row">
		  <div class="col-xl-12">
			 <div class="card">
				<div class="card-body">
				   <h4 class="box-title">Negotiate </h4>
				</div>
				<div class="card-body--">
				   <div class="table-stats order-table ov-h">
					  <table class="table ">
						 <thead>
							<tr>
							   <th class="serial">#</th> 
							   <th>Customer Name/Email</th>
							   <th>Product Name</th>
							   <th>Image</th> 
							   <th>View Offer Price</th>
							   <th>Action</th>
							</tr>
						 </thead>
						 <tbody>
							<?php 
							$i=1;
							while($row=mysqli_fetch_assoc($res)){
								$id = $row['negotation_id'];
								$sql = "select *from negotiation_price where negotiate_id = $id and user_type = 0 and active_status = 1";
								$res_price=mysqli_query($con,$sql);

								$row_price=mysqli_fetch_assoc($res_price);
								// echo"<pre>";print_R($row);die;

								
								?>
							<tr>
							   <td class="serial"><?php echo $i?></td>
							   <td><?php echo $row['name']?> <br><?php echo $row['email']?></td>
							   <td><?php echo $row['p_name']?></td>
							   <td><?php echo $row['image']?></td> 
							   <td>Rs.<?php echo $row_price['price'] ?></td>
							   <td>
								<?php  
									if($row['accept_status'] == 2){
										echo "<span  class='btn btn-md btn-success'>Product Bought</span>&nbsp;"; 
									
									}else{
										echo "<span  class='btn btn-md btn-danger'>Product Not Bought </span>&nbsp;";
									}
									// $check_sql = "select *,product.name as p_name ,negotiations.price as offer_price from negotiations join product on product.id = negotiations.product_id join users on users.id = negotiations.customer_id where product.added_by = $user and user_type = 1 and active_status=1 and accept_status =2"; 
									// $check_res=mysqli_query($con,$check_sql);

									// if(mysqli_num_rows($check_res) > 0){
									// 	while($test_row=mysqli_fetch_assoc($check_res)){
									// 		if($test_row['accept_status'] == 2){
									// 			echo "<span  class='btn btn-md btn-success'>Product Bought</span>&nbsp;"; 
									// 		}
									// 	}  
									// }else{ 
									// 	$test_sql = "select *,product.name as p_name ,negotiations.price as offer_price from negotiations join product on product.id = negotiations.product_id join users on users.id = negotiations.customer_id where product.added_by = $user and user_type = 1 and active_status=1 and accept_status =1"; 
									// 	$test_res=mysqli_query($con,$test_sql);
										
									// 	if(mysqli_num_rows($test_res) > 0){
									// 		while($test_row=mysqli_fetch_assoc($test_res)){
									// 			if($test_row['accept_status'] == 1){
									// 				echo "<span  class='btn btn-md btn-success'>Offer Sent</span>&nbsp;"; 
									// 				echo "<button class='btn btn-md btn-danger' data-toggle='modal' data-target='#send_offer' onclick='offer(".$row['product_id'].",".$row['customer_id'].")'>Send Offer</button>&nbsp;";
									// 			}
									// 		}  
									// 	}else{ 
									// 		echo "<a  class='btn btn-md btn-success' href='?type=status&operation=accept&id=".$row['negotation_id']."'>Accept</a>&nbsp;"; 
									// 		echo "<button class='btn btn-md btn-danger' data-toggle='modal' data-target='#send_offer' onclick='offer(".$row['product_id'].",".$row['customer_id'].")'>Send Offer</button>&nbsp;";
									// 	}
									// }
									
									
								?>
							   </td>
							</tr>
							<?php } ?>
						 </tbody>
					  </table>
				   </div>
				</div>
			 </div>
		  </div>
	   </div>
	</div>
</div>

<div class="modal" id="send_offer" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Send an Offer</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="update_offer" enctype="multipart/form-data" method="post">
          <input type="hidden" id="negotiate_id" name="negotiate_id"> 
          <div class="row">
            <div class="col-12">
              <div class="form-group">
                <label>Offer Amount</label> <br>
                <input type="text" name="offer_amount"><br>				
                <input type="submit" value="Submit" name='send_offer'>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
    <script src="js/vendor/jquery-3.2.1.min.js"></script>
<script>
	function offer(negotiate_id ){
		jQuery('#negotiate_id').val(negotiate_id); 
		// alert(customer_id);
	}
</script>


<?php
require('footer.inc.php');
?>