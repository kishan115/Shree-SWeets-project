<?php
session_start();

/**
 * 
 */
class Message
{
	
	private $con;

	function __construct()
	{
        $this->con=mysqli_connect("localhost","root","","ghatau");
	} 
 
	public function add($text , $conversation_id){  
		$sender = $_SESSION['ADMIN_ID']; 

		// encrypt chat
		$ciphering_value = "AES-128-CTR";   
		// Store the encryption key  
		$encryption_key = "ghatau";  
		// Use openssl_encrypt() function   
		$encryption_value = openssl_encrypt($text, $ciphering_value, $encryption_key);   
		  

		$sql = "INSERT INTO messages(conversation_id ,  account_id , msg) VALUES ('$conversation_id' ,'$sender' ,'$encryption_value')";
		$query = $this->con->query($sql); 
		if ($query == TRUE) {  
			return ['status'=> 202, 'message'=> 'Inserted successfully'];
		}else {
			return ['status'=> 303, 'message'=> 'Insertion Failed'];
		}
	} 

	// insert into messages
	public function view($conversation_id){  
		$sql = "SELECT * FROM messages WHERE conversation_id = $conversation_id order by submit_date ASC";
		$query = $this->con->query($sql);
		$data = [];
		if ($query->num_rows > 0) {   
			$i = 0;
			while($row=mysqli_fetch_assoc($query)){
				array_push($data , $row);
				
					// decrypt chat
					$ciphering_value = "AES-128-CTR";   
					$decryption_key = "ghatau";  
					// Use openssl_decrypt() function to decrypt the data  
					$decryption_value = openssl_decrypt($row['msg'], $ciphering_value, $decryption_key);   

					$data[$i]['msg'] = $decryption_value;
					$i++;
			}  
			return ['status'=> 202, 'message'=> 'Inserted successfully' , 'data' => $data]; 
		}else { 
			return ['status'=> 303, 'message'=> 'Insertion Failed'];
		}	
	} 
 	
} 

// redirect to view function on ajax call
if (isset($_POST["view_chat"])) {
	$conversation_id = $_POST['conversation_id']; 
	$a = new Message(); 
	echo json_encode($a->view($conversation_id));
	exit();	
}

// redirect to add function on ajax call
if (isset($_POST["add_receiver_chat"])) {
	$text = $_POST['text'];
	$conversation_id = $_POST['conversation_id'];
	$a = new Message(); 
	echo json_encode($a->add($text , $conversation_id));
	exit();	
}
 
?>