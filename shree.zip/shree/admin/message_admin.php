<?php
require('top.inc.php'); 

$user = $_SESSION['ADMIN_ID']; 
if(isset($_GET['type']) && $_GET['type']!=''){
	$type=get_safe_value($con,$_GET['type']);
	if($type=='status'){ 
		$id=get_safe_value($con,$_GET['id']);

		$get_sql = "select * from negotiation_price where id = $id";
		$info=mysqli_query($con,$get_sql);
		$row=mysqli_fetch_assoc($info);
		// echo"<pre>";print_R($row);die;
		$price = $row['price'];
		$user_type = 1;
		$user_id = $user;
		$negotiation_id = $row['negotiate_id'];

		$insert_sql ="INSERT into negotiation_price(negotiate_id , price , user_id , user_type , active_status) values('$negotiation_id', '$price' , '$user_id' , '$user_type','1')";
		$result = mysqli_query($con,$insert_sql);


		$update_sql = "UPDATE negotiations SET accept_status='1' WHERE negotation_id = '$negotiation_id'";
		$res=mysqli_query($con,$update_sql); 
			// print_R($result);die;
		
	}
	if($type=='delete'){
		$id=get_safe_value($con,$_GET['id']);
		$delete_sql="delete from product_review where id='$id'";
		mysqli_query($con,$delete_sql);
	}
}


if(isset($_POST['send_offer'])){
	//prx($_POST);
	$product_id=get_safe_value($con,$_POST['product_id']);
	$offer_amount=get_safe_value($con,$_POST['offer_amount']);
	$customer_id=get_safe_value($con,$_POST['customer_id']); 	 
	$user_type = 1;
	$user_id = $user;

	$get_sql = "select * from negotiation_price where id = $id";
	$info=mysqli_query($con,$get_sql);
	$row=mysqli_fetch_assoc($info); 
	$negotiation_id = $row['negotiate_id'];

	$updatesql = "UPDATE negotiation_price SET active_status='0' WHERE user_type = '$user_type' and negotiate_id = '$negotiation_id'";
	$updateres=mysqli_query($con,$updatesql); 

	// print_R($updateres);die;

	$insert_sql ="INSERT into negotiation_price(negotiate_id , price , user_id , user_type , active_status) values('$negotiation_id', '$offer_amount' , '$user_id' , '$user_type','1')"; 
	$result = mysqli_query($con,$insert_sql); 

	if($result==TRUE){ 
		redirect('negotiate.php');
	}
}
 
$sql = "select *,conversations.id as conversation_id from conversations join users on users.id = conversations.account_sender_id where conversations.account_receiver_id = $user";
$res=mysqli_query($con,$sql);
// echo"<pre>";print_R($res);die;

?>
<div class="content pb-0">
	<div class="orders">
	   <div class="row">
		  <div class="col-xl-12">
			 <div class="card">
				<div class="card-body">
				   <h4 class="box-title">Messages</h4>
				</div>
				<div class="card-body--">
				   <div class="table-stats order-table ov-h">
					  <table class="table ">
						 <thead>
							<tr>
							   <th class="serial">#</th> 
							   <th>Customer Name/Email</th>
							   <th>View Messages</th> 
							</tr>
						 </thead>
						 <tbody>
							<?php 
							$i=1;
							while($row=mysqli_fetch_assoc($res)){ 
								// echo"<pre>";print_R($row);die;
								?>
							<tr>
							   <td class="serial"><?php echo $i?></td>
							   <td><?php echo $row['name']?> <br><?php echo $row['email']?></td>
							   <td>
									<?php 
										echo "<button class='btn btn-md btn-danger' data-toggle='modal' data-target='#send_chat' onclick='offer(".$row['conversation_id'].")'>Chat</button>&nbsp;";									
									?>
							   </td>
							</tr>
							<?php } ?>
						 </tbody>
					  </table>
				   </div>
				</div>
			 </div>
		  </div>
	   </div>
	</div>
</div>

<div class="modal" id="send_chat" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
		<div class="modal-header">
			<h5 class="modal-title" id="exampleModalLabel">Messages</h5>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true">&times;</span>
			</button>
		</div>
		<div class="modal-body">
			<div class="wrapper sidebar" id='sidebar_chat'>  
				<div class="form"></div>
				<div class="typing-field">
					<div class="input-data">
						<input type="hidden" id="conversation_id">
						<input id="data" type="text" placeholder="Type something here.." required> 
						<button id="send-btn">Send</button>
					</div>
				</div>	
			</div>

        
      </div>
    </div>
  </div>
</div>
    <script src="../js/vendor/jquery-3.2.1.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script>
	function offer(conversation_id){ 
		var user_id = <?php echo $user; ?>;
		
		$('#conversation_id').val(conversation_id);
		 // start ajax code
		$('.form').empty();
		$.ajax({
			url: 'Message.php',
			type: 'POST',
			data: { conversation_id : conversation_id  , view_chat : 1 }, 
			success: function(msg){

				var result = $.parseJSON(msg);
				console.log(result);
				if (result.status == 202) {
					console.log(result.data);
					var i = 0;
					var reply ='';
					$.each(result.data, function(index, value) { 
						console.log(value['account_id']);
						if ( user_id == value['account_id'] ){
							reply += '<div class="user-inbox inbox"><div class="icon"><i class="fas fa-user"></i></div><div class="msg-header"><p>'+ value['msg'] +'</p></div></div>'; 
						}else{
							reply += '<div class="bot-inbox inbox"><div class="icon"><i class="fas fa-user"></i></div><div class="msg-header"><p>'+ value['msg'] +'</p></div></div>';
						}
					}); 
					$(".form").append(reply);

				} else {
					alert(result.message);
				}
			}
		}); 
	}

	$( "#send_chat" ).on('shown.bs.modal', function(){  
		view_Interval = setInterval(view_reload, 5000);
	});

	
	$( "#send_chat" ).on('hidden.bs.modal', function(){  
		clearInterval(view_Interval);
	});
 
	function view_reload(){
		var user_id = <?php echo $user; ?>;
	
		var conversation_id = $('#conversation_id').val();
		// start ajax code
		$('.form').empty();
		$.ajax({
			url: 'Message.php',
			type: 'POST',
			data: { conversation_id : conversation_id  , view_chat : 1 }, 
			success: function(msg){

				var result = $.parseJSON(msg);
				console.log(result);
				if (result.status == 202) {
					console.log(result.data);
					var i = 0;
					var reply ='';
					$.each(result.data, function(index, value) { 
						console.log(value['account_id']);
						if ( user_id == value['account_id'] ){
							reply += '<div class="user-inbox inbox"><div class="icon"><i class="fas fa-user"></i></div><div class="msg-header"><p>'+ value['msg'] +'</p></div></div>'; 
						}else{
							reply += '<div class="bot-inbox inbox"><div class="icon"><i class="fas fa-user"></i></div><div class="msg-header"><p>'+ value['msg'] +'</p></div></div>';
						}
					}); 
					$(".form").append(reply);

				} else {
					alert(result.message);
				}
			}
		}); 
	}

	$("#send-btn").on("click", function(){
		var value = $("#data").val();
		var conversation_id = $("#conversation_id").val(); 
		
		var msg = '<div class="user-inbox inbox"><div class="icon"><i class="fas fa-user"></i></div><div class="msg-header"><p>'+ value +'</p></div></div>';
		$(".form").append(msg);
		$("#data").val('');
		
		// start ajax code
		$.ajax({
			url: 'Message.php',
			type: 'POST',
			data: {text : value , conversation_id : conversation_id , add_receiver_chat : 1 }, 
			success: function(result){
				console.log(result);
				// $replay = '<div class="bot-inbox inbox"><div class="icon"><i class="fas fa-user"></i></div><div class="msg-header"><p>'+ result +'</p></div></div>';
				// $(".form").append($replay);
				// // when chat goes down the scroll bar automatically comes to the bottom
				// $(".form").scrollTop($(".form")[0].scrollHeight);
			}
		});
	});
</script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
<!-- css for chat box  -->
<style>
   @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');

    ::-webkit-scrollbar{
        width: 3px;
        border-radius: 25px;
    }
    ::-webkit-scrollbar-track{
        background: #f1f1f1;
    }
    ::-webkit-scrollbar-thumb{
        background: #ddd;
    }
    ::-webkit-scrollbar-thumb:hover{
        background: #ccc;
    }
.wrapper .title{
        background: #007bff;
        color: #fff;
        font-size: 20px;
        font-weight: 500;
        line-height: 60px;
        text-align: center;
        border-bottom: 1px solid #006fe6;
        border-radius: 5px 5px 0 0;
    }
    .wrapper .form{
        padding: 20px 15px;
        min-height: 400px;
        max-height: 400px;
        overflow-y: auto;
    }
    .wrapper .form .inbox{
        width: 100%;
        display: flex;
        align-items: baseline;
    }
    .wrapper .form .user-inbox{
        justify-content: flex-end;
        margin: 13px 0;
    }
    .wrapper .form .inbox .icon{
        height: 40px;
        width: 40px;
        color: #fff;
        text-align: center;
        line-height: 40px;
        border-radius: 50%;
        font-size: 18px;
        background: #007bff;
    }
    .wrapper .form .inbox .msg-header{
        max-width: 53%;
        margin-left: 10px;
    }
    .form .inbox .msg-header p{
        color: #fff;
        background: #007bff;
        border-radius: 10px;
        padding: 8px 10px;
        font-size: 14px;
        word-break: break-all;
    }
    .form .user-inbox .msg-header p{
        color: #333;
        background: #efefef;
    }
    .wrapper .typing-field{
        display: flex;
        height: 60px;
        width: 100%;
        align-items: center;
        justify-content: space-evenly;
        background: #efefef;
        border-top: 1px solid #d9d9d9;
        border-radius: 0 0 5px 5px;
    }
    .wrapper .typing-field .input-data{
        height: 40px;
        width: 335px;
        position: relative;
    }
    .wrapper .typing-field .input-data input{
        height: 100%;
        width: 100%;
        outline: none;
        border: 1px solid transparent;
        padding: 0 80px 0 15px;
        border-radius: 3px;
        font-size: 15px;
        background: #fff;
        transition: all 0.3s ease;
    }
    .typing-field .input-data input:focus{
        border-color: rgba(0,123,255,0.8);
    }
    .input-data input::placeholder{
        color: #999999;
        transition: all 0.3s ease;
    }
    .input-data input:focus::placeholder{
        color: #bfbfbf;
    }
    .wrapper .typing-field .input-data button{
        position: absolute;
        right: 5px;
        top: 50%;
        height: 30px;
        width: 65px;
        color: #fff;
        font-size: 16px;
        cursor: pointer;
        outline: none;
        opacity: 0;
        pointer-events: none;
        border-radius: 3px;
        background: #007bff;
        border: 1px solid #007bff;
        transform: translateY(-50%);
        transition: all 0.3s ease;
    }
    .wrapper .typing-field .input-data input:valid ~ button{
        opacity: 1;
        pointer-events: auto;
    }
    .typing-field .input-data button:hover{
        background: #006fef;
    }
</style>

<?php
require('footer.inc.php');
?>