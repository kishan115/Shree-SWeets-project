
<?php 
require('top.php');
require "Authenticator.php";
$Authenticator = new Authenticator();
if (!isset($_SESSION['auth_secret'])) {
    $secret = $Authenticator->generateRandomSecret();
    $_SESSION['auth_secret'] = $secret;
}
$qrCodeUrl = $Authenticator->getQR('myPHPnotes', $_SESSION['auth_secret']);

if (!isset($_SESSION['failed'])) {
    $_SESSION['failed'] = false;
}
?>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<!-- Start Bradcaump area -->
<div class="ht__bradcaump__area" style="background: rgba(0, 0, 0, 0) url(images/bg/4.jpg) no-repeat scroll center center / cover ;">
    <div class="ht__bradcaump__wrap">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="bradcaump__inner">
                        <nav class="bradcaump-inner">
                            <a class="breadcrumb-item" href="index.php">Home</a>
                            <span class="brd-separetor"><i class="zmdi zmdi-chevron-right"></i></span>
                            <span class="breadcrumb-item active">Register</span>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Bradcaump area -->		

<!-- Start Contact Area -->
<section class="htc__contact__area ptb--100 bg__white">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="contact-form-wrap mt--60">
                    <div class="col-xs-12">
                        <div class="contact-title">
                            <h2 class="title__line--6">Register</h2>
                        </div>
                    </div> 
                    <div class="col-xs-12">
                        <form id="register-form" method="post">
                            <div class="single-contact-form">
                                <div class="contact-box name">
                                    <input type="text" name="name" id="name" placeholder="Your Name*" style="width:100%">
                                </div>
                                <span class="field_error" id="name_error"></span>
                            </div>
                            <div class="single-contact-form">
                                <div class="contact-box name">
                                    <input type="text" name="email" id="email" placeholder="Your Email*" style="width:100%">
                                </div>
                                <span class="field_error" id="email_error"></span>
                            </div>
                            <div class="single-contact-form">
                                <div class="contact-box name">
                                    <input type="text" name="mobile" id="mobile" placeholder="Your Mobile*" style="width:100%">
                                </div>
                                <span class="field_error" id="mobile_error"></span>
                            </div>
                            
                            <div class="single-contact-form">
                                <div class="contact-box name">
                                    <input type="password" name="password" id="password" placeholder="Your Password*" style="width:100%">
                                </div>
                                <span class="field_error" id="password_error"></span>
                            </div>
                            <br>
                            <div class="g-recaptcha" data-sitekey="6LfQfo0lAAAAACqP1ntlG2FKj93hAfOlRiF5mYVT"></div>
                            
                            <div class="contact-btn">
                                <button type="button" class="fv-btn" id='register_btn' onclick="user_register()">Register</button>
                            </div>
                        </form>
                        <div class="form-output register_msg">
                            <p class="form-messege field_error"></p>
                        </div>
                    </div>
                </div> 
            </div>
        </div>
    </div>
</section> 
<?php require('footer.php')?>  
<script> 
function user_register(){
    jQuery('.field_error').html('');
    var name=jQuery("#name").val();
    var email=jQuery("#email").val();
    var mobile=jQuery("#mobile").val();
    var password=jQuery("#password").val();
    var is_error=''; 
    var g_recaptcha_response =  grecaptcha.getResponse();
    if(name==""){
        jQuery('#name_error').html('Please enter name');
        is_error='yes';
    }if(email==""){
        jQuery('#email_error').html('Please enter email');
        is_error='yes';
    }if(mobile==""){
        jQuery('#mobile_error').html('Please enter mobile');
        is_error='yes';
    }if(password==""){
        jQuery('#password_error').html('Please enter password');
        is_error='yes';
    }

    // regular expression to check a password between 8 to 15 characters which contain at least one lowercase letter, one uppercase letter, one numeric digit, and one special character
    var decimal=  /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
    
    // validates password
    if(!(password.match(decimal))){ 
        jQuery('#password_error').html('Please enter a strong password.(a password between 8 to 15 characters which contain at least one lowercase letter, one uppercase letter, one numeric digit, and one special character)');
        is_error='yes';
    } 

    if(is_error==''){
        jQuery.ajax({
            url:'register_submit.php',
            type:'post',
            data:'name='+name+'&email='+email+'&mobile='+mobile+'&password='+password+'&g_recaptcha_response='+g_recaptcha_response,
            success:function(result){
                console.log(result);
                result=result.trim();
                console.log(result);
                if(result=='email_present'){
                    jQuery('#email_error').html('Email id already present');
                }
                if(result=='mobile_present'){
                    jQuery('#mobile_error').html('Mobile number already present');
                }
                if(result=='insert'){
                    jQuery('.register_msg p').html('Thank you for registeration');
                    location.reload(); 
                }
                if(result=='Recaptcha Validation Error'){
                    alert('Recaptcha Validation Error');
                }
                if(result=='Please fill Recaptcha'){
                    alert('Please fill Recaptcha');
                }
            }    
        });
    }
    
}
</script>
