-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2023 at 01:58 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shree`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password`, `role`, `email`, `mobile`, `status`) VALUES
(1, 'admin', 'admin', 0, '', '', 1),
(2, 'vishal', 'vishal', 1, 'vishal@gmail.com', '1234567890', 1),
(3, 'amit', 'amit', 1, 'amit@gmail.com', '1234567890', 1),
(5, 'vishal1', 'vishal', 1, 'vishal@gmail.com', '1234567890', 1),
(6, 'sai', 'sai', 1, 'admin@sai.com', '9861967556', 1);

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `id` int(11) NOT NULL,
  `heading1` varchar(255) NOT NULL,
  `heading2` varchar(255) NOT NULL,
  `btn_txt` varchar(255) DEFAULT NULL,
  `btn_link` varchar(55) DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `order_no` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`id`, `heading1`, `heading2`, `btn_txt`, `btn_link`, `image`, `order_no`, `status`) VALUES
(1, 'collection 2018', 'NICE CHAIR', 'Share Now', 'cart.php', '141838360_368356647_online-shopping-e-commerce-banner-concept-vector-25035204.jpg', 2, 0),
(2, 'Collection 2021', 'I m Heading', '', '', '163630926_2.png', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `categories` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `categories`, `status`) VALUES
(1, 'Mobile', 1),
(2, 'Man', 1),
(4, 'Woman', 1);

-- --------------------------------------------------------

--
-- Table structure for table `color_master`
--

CREATE TABLE `color_master` (
  `id` int(11) NOT NULL,
  `color` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `color_master`
--

INSERT INTO `color_master` (`id`, `color`, `status`) VALUES
(1, 'Red', 1),
(3, 'Black', 1),
(4, 'Pink', 1),
(5, 'Green', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(75) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `comment` text NOT NULL,
  `added_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `name`, `email`, `mobile`, `comment`, `added_on`) VALUES
(1, 'Vishal', 'vishal@gmail.com', '1234567890', 'Test Query', '2020-01-14 00:00:00'),
(2, 'vishal@gmail.com', '', '1234567890', 'testing', '2020-01-19 07:59:38'),
(3, 'Vishal', 'vishal@gmail.com', '1234567890', 'testing', '2020-01-19 08:00:09'),
(4, 'test', 'test@gmail.com', '9990413778', 'test', '2020-05-01 09:21:37');

-- --------------------------------------------------------

--
-- Table structure for table `conversations`
--

CREATE TABLE `conversations` (
  `id` int(11) NOT NULL,
  `account_sender_id` int(11) NOT NULL,
  `account_receiver_id` int(11) NOT NULL,
  `submit_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `conversations`
--

INSERT INTO `conversations` (`id`, `account_sender_id`, `account_receiver_id`, `submit_date`) VALUES
(1, 2, 1, '0000-00-00 00:00:00'),
(2, 4, 1, '0000-00-00 00:00:00'),
(3, 4, 6, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `coupon_master`
--

CREATE TABLE `coupon_master` (
  `id` int(11) NOT NULL,
  `coupon_code` varchar(50) NOT NULL,
  `coupon_value` int(11) NOT NULL,
  `coupon_type` varchar(10) NOT NULL,
  `cart_min_value` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coupon_master`
--

INSERT INTO `coupon_master` (`id`, `coupon_code`, `coupon_value`, `coupon_type`, `cart_min_value`, `status`) VALUES
(1, 'First50', 1000, 'Rupee', 1500, 1),
(2, 'First60', 20, 'Percentage', 1000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `conversation_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `msg` text NOT NULL,
  `submit_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `conversation_id`, `account_id`, `msg`, `submit_date`) VALUES
(1, 1, 2, 'wLzCSQho6LgXq3I=', '2023-04-02 09:24:22'),
(2, 1, 2, '3LzdUQ4m+/ABtnpcZ6Ou0NwZq0xzJESmrbiDRhm2xLw=', '2023-04-02 09:28:13'),
(3, 1, 1, '27bDQEc++b4WtmUZI6a7xZ1NsAMxIwHjprWSRhm2xLw=', '2023-04-02 09:36:12'),
(4, 2, 4, '3LzdUQ4m+/ARtnlPIrW8xclQsE1zNVXnuqKFW0mj0vgJ/wvmfYxSs2s/bWI8Xg==', '2023-04-02 09:37:34'),
(5, 2, 1, 'x7KOVhIr/7UBqnFMK6u2hM9cvEY6METi6L+OHwimzLECsQ==', '2023-04-02 09:37:54'),
(6, 2, 4, '3LzdUQ4m+w==', '2023-04-02 09:42:28'),
(7, 2, 4, '27bDQEc8+aMG', '2023-04-02 09:43:29'),
(8, 3, 4, 'xLzaVkcr9LEG', '2023-04-02 22:07:06'),
(9, 3, 6, 'x7KOVggl+fARsXZNZ6+q1thO', '2023-04-02 22:07:54');

-- --------------------------------------------------------

--
-- Table structure for table `negotiations`
--

CREATE TABLE `negotiations` (
  `negotation_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `accept_status` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `negotiations`
--

INSERT INTO `negotiations` (`negotation_id`, `product_id`, `accept_status`, `customer_id`, `created_at`) VALUES
(3, 32, 2, 2, '2023-03-30 15:51:34'),
(4, 32, 2, 2, '2023-03-30 17:55:33'),
(5, 32, 0, 0, '2023-03-30 21:50:48'),
(6, 32, 2, 4, '2023-03-31 15:35:30'),
(7, 32, 2, 2, '2023-04-02 09:14:19'),
(8, 32, 2, 4, '2023-04-02 09:45:21'),
(9, 33, 1, 4, '2023-04-02 22:06:51');

-- --------------------------------------------------------

--
-- Table structure for table `negotiation_price`
--

CREATE TABLE `negotiation_price` (
  `id` int(11) NOT NULL,
  `negotiate_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_type` int(11) NOT NULL,
  `price` varchar(255) NOT NULL,
  `active_status` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `negotiation_price`
--

INSERT INTO `negotiation_price` (`id`, `negotiate_id`, `user_id`, `user_type`, `price`, `active_status`, `created_at`) VALUES
(3, 3, 2, 0, '20005', 0, '2023-03-30 15:51:34'),
(4, 3, 2, 0, '20000', 0, '2023-03-30 15:56:44'),
(5, 3, 2, 0, '20000', 0, '2023-03-30 15:56:44'),
(7, 3, 2, 0, '20006', 0, '2023-03-30 15:58:46'),
(8, 3, 2, 0, '200069', 1, '2023-03-30 15:59:29'),
(14, 3, 1, 1, '200069', 0, '2023-03-30 17:39:14'),
(15, 3, 1, 1, '200069', 0, '2023-03-30 17:40:12'),
(16, 3, 1, 1, '200069', 0, '2023-03-30 17:44:52'),
(17, 3, 1, 1, '200069', 0, '2023-03-30 17:44:58'),
(18, 3, 1, 1, '25', 1, '2023-03-30 17:44:58'),
(19, 4, 2, 0, '20000', 0, '2023-03-30 17:55:33'),
(20, 4, 1, 1, '20000', 0, '2023-03-30 17:55:46'),
(21, 4, 1, 1, '20000', 0, '2023-03-30 17:56:01'),
(22, 4, 1, 1, '123', 0, '2023-03-30 17:56:02'),
(23, 5, 0, 0, '', 0, '2023-03-30 21:50:48'),
(24, 5, 0, 0, '', 0, '2023-03-30 21:50:49'),
(25, 5, 0, 0, '', 0, '2023-03-30 21:50:50'),
(26, 5, 0, 0, '', 0, '2023-03-30 21:50:50'),
(27, 5, 0, 0, '', 1, '2023-03-30 21:50:50'),
(28, 6, 4, 0, '20000', 0, '2023-03-31 15:35:30'),
(29, 0, 1, 1, '200005', 0, '2023-03-31 15:39:26'),
(30, 0, 1, 1, '123', 0, '2023-03-31 15:39:52'),
(31, 6, 1, 1, '20000', 0, '2023-03-31 15:41:51'),
(32, 6, 1, 1, '20000', 0, '2023-03-31 15:42:41'),
(33, 6, 1, 1, '20000', 0, '2023-03-31 15:45:53'),
(34, 6, 1, 1, '20000', 0, '2023-03-31 15:46:12'),
(35, 6, 1, 1, '123', 0, '2023-03-31 15:46:12'),
(36, 6, 1, 1, '123123', 0, '2023-03-31 15:46:21'),
(37, 6, 1, 1, '690000', 0, '2023-03-31 16:47:30'),
(38, 4, 2, 0, '200022', 0, '2023-04-01 08:26:08'),
(39, 4, 2, 0, '21000', 0, '2023-04-01 09:38:04'),
(40, 4, 2, 0, '21000', 0, '2023-04-01 09:38:06'),
(41, 4, 2, 0, '20000', 0, '2023-04-01 09:38:28'),
(42, 4, 2, 0, '21000', 0, '2023-04-01 09:39:07'),
(43, 6, 4, 0, '21000', 1, '2023-04-01 10:36:41'),
(44, 4, 2, 0, '22222', 1, '2023-04-02 09:07:11'),
(45, 0, 2, 0, '22333', 1, '2023-04-02 09:08:35'),
(46, 0, 2, 0, '223333', 1, '2023-04-02 09:08:57'),
(47, 0, 2, 0, '223333', 1, '2023-04-02 09:11:56'),
(48, 7, 2, 0, '223333', 1, '2023-04-02 09:14:20'),
(49, 8, 4, 0, '21000', 1, '2023-04-02 09:45:21'),
(50, 9, 4, 0, '2000', 0, '2023-04-02 22:06:51'),
(51, 9, 4, 0, '2300', 1, '2023-04-03 11:53:31');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `address` varchar(250) NOT NULL,
  `city` varchar(50) NOT NULL,
  `pincode` int(11) NOT NULL,
  `payment_type` varchar(20) NOT NULL,
  `total_price` float NOT NULL,
  `payment_status` varchar(20) NOT NULL,
  `payment_token` varchar(255) NOT NULL,
  `payment_user` varchar(255) NOT NULL,
  `order_status` int(11) NOT NULL,
  `length` float NOT NULL,
  `breadth` float NOT NULL,
  `height` float NOT NULL,
  `weight` float NOT NULL,
  `txnid` varchar(200) NOT NULL,
  `mihpayid` varchar(200) NOT NULL,
  `ship_order_id` int(11) NOT NULL,
  `ship_shipment_id` int(11) NOT NULL,
  `payu_status` varchar(10) NOT NULL,
  `coupon_id` int(11) NOT NULL,
  `coupon_value` varchar(50) NOT NULL,
  `coupon_code` varchar(50) NOT NULL,
  `added_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id`, `user_id`, `address`, `city`, `pincode`, `payment_type`, `total_price`, `payment_status`, `payment_token`, `payment_user`, `order_status`, `length`, `breadth`, `height`, `weight`, `txnid`, `mihpayid`, `ship_order_id`, `ship_shipment_id`, `payu_status`, `coupon_id`, `coupon_value`, `coupon_code`, `added_on`) VALUES
(1, 0, '', '', 0, 'payu', 0, 'Success', '', '0', 5, 0, 0, 0, 0, '', '', 0, 0, '', 0, '', '', '0000-00-00 00:00:00'),
(2, 2, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 2399, 'pending', '', '0', 1, 0, 0, 0, 0, '4bf966c95b89374fa939', '', 0, 0, '', 0, '', '', '2023-03-23 04:41:21'),
(3, 2, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 2399, 'pending', '', '0', 1, 0, 0, 0, 0, '3c7d3521153672626967', '', 0, 0, '', 0, '', '', '2023-03-23 04:43:25'),
(4, 2, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 20002, 'pending', '', '0', 1, 0, 0, 0, 0, 'dda2c96b63994ef5008b', '', 0, 0, '', 0, '', '', '2023-03-27 10:01:28'),
(5, 2, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 20002, 'pending', '', '0', 1, 0, 0, 0, 0, '42504713486116a39d42', '', 0, 0, '', 0, '', '', '2023-03-27 10:16:07'),
(6, 2, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 20002, 'pending', '', '0', 1, 0, 0, 0, 0, '08bbd2925982ba26301d', '', 0, 0, '', 0, '', '', '2023-03-27 10:49:46'),
(7, 2, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 20002, 'pending', '', '0', 1, 0, 0, 0, 0, 'e1e9d12462b7056d7c52', '', 0, 0, '', 0, '', '', '2023-03-27 10:50:17'),
(8, 2, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 1230000, 'pending', '', '0', 1, 0, 0, 0, 0, '0ab2552491d11f5c8c15', '', 0, 0, '', 0, '', '', '2023-03-29 01:20:24'),
(9, 2, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 1230000, 'pending', '', '0', 1, 0, 0, 0, 0, '53f1d87850031194ceb8', '', 0, 0, '', 0, '', '', '2023-03-29 01:24:03'),
(10, 2, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 1230000, 'pending', '', '0', 1, 0, 0, 0, 0, '6c64000927e35f71ddff', '', 0, 0, '', 0, '', '', '2023-03-30 05:01:59'),
(11, 2, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 1230000, 'pending', '', '0', 1, 0, 0, 0, 0, '0312c35041f36d73b661', '', 0, 0, '', 0, '', '', '2023-03-30 05:05:24'),
(12, 2, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 1230000, 'pending', '', '0', 1, 0, 0, 0, 0, '85fe7915f77c30cf6c7a', '', 0, 0, '', 0, '', '', '2023-03-30 05:06:08'),
(13, 2, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 1230000, 'pending', '', '0', 1, 0, 0, 0, 0, 'd884d9e7abbe282620b6', '', 0, 0, '', 0, '', '', '2023-03-30 05:06:24'),
(14, 2, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 1230000, 'pending', '', '0', 1, 0, 0, 0, 0, '6c85e9e4b42bdfb7e908', '', 0, 0, '', 0, '', '', '2023-03-30 05:06:50'),
(15, 2, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 1230000, 'pending', '', '0', 1, 0, 0, 0, 0, 'ad081e99e08acf0ff353', '', 0, 0, '', 0, '', '', '2023-03-30 05:07:13'),
(16, 2, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 20008, 'pending', '', '0', 1, 0, 0, 0, 0, 'e04529132b57036fde01', '', 0, 0, '', 0, '', '', '2023-03-30 11:46:51'),
(17, 2, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 25, 'pending', '', '0', 1, 0, 0, 0, 0, '197cba21c3ac73e86ecf', '', 0, 0, '', 0, '', '', '2023-03-30 02:09:33'),
(18, 4, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 690000, 'pending', '', '0', 1, 0, 0, 0, 0, '23a3225751708accf585', '', 0, 0, '', 0, '', '', '2023-03-31 01:09:10'),
(19, 4, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 21000, 'pending', '', '0', 1, 0, 0, 0, 0, 'e5c521982a7f7e76ba04', '', 0, 0, '', 0, '', '', '2023-04-01 06:51:56'),
(20, 2, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 22222, 'pending', '', '0', 1, 0, 0, 0, 0, '30a30051e175daa7c5de', '', 0, 0, '', 0, '', '', '2023-04-02 05:22:59'),
(21, 2, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 223333, 'pending', '', '0', 1, 0, 0, 0, 0, '0a96979569cc271072fa', '', 0, 0, '', 0, '', '', '2023-04-02 05:29:44'),
(22, 4, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 21000, 'pending', '', '0', 1, 0, 0, 0, 0, 'e5f8ed302f7ef6a0416a', '', 0, 0, '', 0, '', '', '2023-04-02 06:07:17'),
(23, 4, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 2000, 'pending', '', '0', 1, 0, 0, 0, 0, '76d2d9b5106ad30f8791', '', 0, 0, '', 0, '', '', '2023-04-02 06:22:32'),
(24, 4, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 0, 'pending', '', '0', 1, 0, 0, 0, 0, 'ba2bd7a74f5166944fda', '', 0, 0, '', 0, '', '', '2023-04-02 06:35:53'),
(25, 4, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 2500, 'pending', '', '0', 1, 0, 0, 0, 0, 'bc7c5b41bd55db5db685', '', 0, 0, '', 0, '', '', '2023-04-02 06:39:50'),
(26, 4, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 2300, 'pending', '', '0', 1, 0, 0, 0, 0, '562c2ced5cf058707464', '', 0, 0, '', 0, '', '', '2023-04-03 08:08:44'),
(27, 4, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'COD', 2300, 'pending', '', '0', 1, 0, 0, 0, 0, '4fa06c26087877044c8c', '', 0, 0, '', 0, '', '', '2023-04-03 08:22:35'),
(28, 4, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'khalti', 2300, 'pending', '', '0', 1, 0, 0, 0, 0, '128f7e08692b57d365f1', '', 0, 0, '', 0, '', '', '2023-04-05 11:51:04'),
(29, 4, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'khalti', 2300, 'pending', '', '0', 1, 0, 0, 0, 0, '29384f4f74ebc1fddc3b', '', 0, 0, '', 0, '', '', '2023-04-05 11:51:35'),
(30, 4, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'khalti', 2300, 'pending', '', '0', 1, 0, 0, 0, 0, '5637cfded3c6f16f1ac4', '', 0, 0, '', 0, '', '', '2023-04-05 11:52:08'),
(31, 4, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'khalti', 2300, 'pending', '', '0', 1, 0, 0, 0, 0, '182a9b028f50b336d448', '', 0, 0, '', 0, '', '', '2023-04-05 11:53:47'),
(32, 4, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'khalti', 2300, 'pending', '', '0', 1, 0, 0, 0, 0, '05c133555d68bf568386', '', 0, 0, '', 0, '', '', '2023-04-05 11:53:57'),
(33, 4, 'Shorekhutte, Kathmandu', 'kathmandu', 4600, 'khalti', 2300, 'Paid', 'WEiBPu37haXyRqb9FangpB', 'Sai Shrestha (9861967556)', 1, 0, 0, 0, 0, 'a03da848f6a0a563116b', '', 0, 0, '', 0, '', '', '2023-04-05 11:54:22');

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_attr_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`id`, `order_id`, `product_id`, `product_attr_id`, `qty`, `price`) VALUES
(1, 1, 7, 5, 10, 333),
(2, 2, 5, 10, 1, 2399),
(3, 3, 5, 10, 1, 2399),
(4, 4, 31, 18, 2, 10001),
(5, 5, 31, 18, 2, 10001),
(6, 6, 31, 18, 2, 10001),
(7, 7, 31, 18, 2, 10001),
(8, 8, 32, 19, 1, 20000),
(9, 9, 32, 19, 1, 1230000),
(10, 10, 32, 19, 1, 1230000),
(11, 11, 32, 19, 1, 1230000),
(12, 12, 32, 19, 1, 1230000),
(13, 13, 32, 19, 1, 1230000),
(14, 14, 32, 19, 1, 1230000),
(15, 15, 32, 19, 1, 1230000),
(16, 16, 32, 19, 1, 20008),
(17, 17, 32, 19, 1, 25),
(18, 18, 32, 19, 1, 690000),
(19, 19, 32, 19, 1, 21000),
(20, 20, 32, 19, 1, 22222),
(21, 21, 32, 19, 1, 223333),
(22, 22, 32, 19, 1, 21000),
(23, 23, 33, 20, 1, 2000),
(24, 24, 33, 20, 1, 0),
(25, 25, 33, 20, 1, 2500),
(26, 26, 33, 20, 1, 2300),
(27, 27, 33, 20, 1, 2300),
(28, 28, 33, 20, 1, 2300),
(29, 29, 33, 20, 1, 2300),
(30, 30, 33, 20, 1, 2300),
(31, 31, 33, 20, 1, 2300),
(32, 32, 33, 20, 1, 2300),
(33, 33, 33, 20, 1, 2300);

-- --------------------------------------------------------

--
-- Table structure for table `order_status`
--

CREATE TABLE `order_status` (
  `id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `order_status`
--

INSERT INTO `order_status` (`id`, `name`) VALUES
(1, 'Pending'),
(2, 'Processing'),
(3, 'Shipped'),
(4, 'Canceled'),
(5, 'Complete');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `categories_id` int(11) NOT NULL,
  `sub_categories_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mrp` float NOT NULL,
  `price` float NOT NULL,
  `qty` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `short_desc` varchar(2000) NOT NULL,
  `description` text NOT NULL,
  `best_seller` int(11) NOT NULL,
  `meta_title` varchar(2000) NOT NULL,
  `meta_desc` varchar(2000) NOT NULL,
  `meta_keyword` varchar(2000) NOT NULL,
  `added_by` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `categories_id`, `sub_categories_id`, `name`, `mrp`, `price`, `qty`, `image`, `short_desc`, `description`, `best_seller`, `meta_title`, `meta_desc`, `meta_keyword`, `added_by`, `status`) VALUES
(1, 1, 0, 'Realme C3 (Frozen Blue, 64 GB) (4 GB RAM)', 9999, 8999, 10, '799153645_303b4a46-a701-4b43-b9c1-d98a2b53422f.jpg', 'Mauris dapibus tellus quis risus maximus molestie. Curabitur eget tortor tellus.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus scelerisque quis nisi porta congue. Aenean sed maximus ligula. Vestibulum quis eros id ex condimentum lacinia. Nam interdum finibus odio, sit amet commodo erat varius sed. In at velit velit. Nullam vitae gravida mi. Donec aliquet nunc non ipsum bibendum, et elementum nibh lobortis. Fusce tempor elit at mauris luctus euismod. Donec eu massa eros. Aenean maximus vitae nisl ut sollicitudin. Aenean urna arcu, laoreet at ante eget, maximus mattis lacus. Mauris dapibus tellus quis risus maximus molestie. Curabitur eget tortor tellus.', 1, 'Realme C3 (Frozen Blue, 64 GB) (4 GB RAM)', '', 'Realme C3 (Frozen Blue, 64 GB) (4 GB RAM)', 0, 1),
(2, 1, 0, 'APPLE IPHONE 11 PRO MAX (512GB) - MIDNIGHT GREEN', 165800, 155800, 4, '942626953_iphone.jpg', 'Aenean tempus ut leo nec laoreet. Vestibulum ut est neque.', 'Curabitur eget augue dolor. Curabitur id dapibus massa. Vestibulum at enim quis metus ultrices posuere vitae sit amet eros. Morbi et libero pellentesque, efficitur odio nec, congue lorem. Vestibulum faucibus, risus eget pretium efficitur, neque nulla eleifend purus, non venenatis lorem ligula vel nulla. Fusce finibus efficitur sapien vitae laoreet. Integer imperdiet justo sed tellus dictum, at egestas arcu finibus. Fusce et augue elit. Praesent tincidunt purus in purus dictum volutpat. Aenean tempus ut leo nec laoreet. Vestibulum ut est neque.', 0, 'APPLE IPHONE 11 PRO MAX (512GB) - MIDNIGHT GREEN', '', 'APPLE IPHONE 11 PRO MAX (512GB) - MIDNIGHT GREEN', 0, 1),
(3, 1, 0, 'Samsung Galaxy S10 Plus 1TB (Ceramic White, 12GB RAM)', 115900, 115900, 5, '567328558_samsung-galaxy-s10-plus-1tb-ceramic-white-12gb-ram-.jpg', 'Nullam purus lorem, tincidunt vitae tristique non, imperdiet ut urna.', 'Nullam a nunc et lorem ornare faucibus. Etiam tortor lacus, auctor eget enim at, tincidunt dignissim magna. Interdum et malesuada fames ac ante ipsum primis in faucibus. Proin tincidunt eros eget felis tempor, id volutpat ipsum lacinia. Donec scelerisque risus non purus scelerisque tristique. Mauris enim ligula, condimentum sed iaculis nec, porttitor eu nunc. Sed hendrerit vel arcu vitae iaculis. Phasellus vehicula molestie leo. Nullam purus lorem, tincidunt vitae tristique non, imperdiet ut urna.', 0, 'Samsung Galaxy S10 Plus 1TB (Ceramic White, 12GB RAM)', 'Samsung Galaxy S10 Plus 1TB (Ceramic White, 12GB RAM)', 'Samsung Galaxy S10 Plus 1TB (Ceramic White, 12GB RAM)', 0, 1),
(4, 2, 2, 'SHEEN-SOLID TROUSER-OLIVE', 1999, 1200, 3, '697347005_2__1538219531_49.204.69.38_600x.jpg', 'per inceptos himenaeos. Ut commodo ullamcorper quam non pulvinar.', 'Duis a felis congue, feugiat est non, suscipit quam. In elit lacus, auctor sed lacus eget, egestas consectetur leo. Duis pellentesque pharetra ante, ac ornare nibh faucibus id. Integer pulvinar malesuada nisl. Nulla vel orci nunc. Nullam a tellus eu ex ullamcorper mollis. Donec commodo ligula a accumsan fermentum. Mauris sed orci lacinia, posuere leo molestie, pretium mi. Cras sodales, neque id cursus fermentum, mi purus vehicula sem, vel laoreet lorem justo id tortor. Sed ut urna ut ipsum vestibulum commodo. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Ut commodo ullamcorper quam non pulvinar.', 0, 'SHEEN-SOLID TROUSER-OLIVE', 'SHEEN-SOLID TROUSER-OLIVE', 'SHEEN-SOLID TROUSER-OLIVE', 0, 1),
(5, 2, 1, 'NATURE-LINEN SHIRT-GREEN', 2799, 2399, 8, '812581380_nature_green-0224_600x.jpg', 'a nisl pharetra orci, at condimentum nisl lorem elementum ipsum.', 'Nunc auctor turpis ante, eget bibendum mi mollis in. Aliquam quis neque ut libero malesuada auctor. Aliquam interdum enim at commodo gravida. Donec nisl sem, molestie ut quam quis, vulputate venenatis ipsum. Aenean quis ex ut magna accumsan fringilla. Quisque id ex massa. Sed libero ante, fringilla ac condimentum in, porttitor ac risus. Integer mattis odio nec nunc semper imperdiet. In porttitor tellus eget sapien vulputate, eu euismod lacus aliquet. Maecenas molestie elit augue, sit amet fringilla dolor congue et. Nunc eu libero auctor, sollicitudin lectus quis, porta ligula. In vel ullamcorper risus. Nullam viverra, mi sit amet laoreet luctus, urna nisl pharetra orci, at condimentum nisl lorem elementum ipsum.', 0, 'NATURE-LINEN SHIRT-GREEN', 'NATURE-LINEN SHIRT-GREEN', 'T-Shirt, NATURE-LINEN SHIRT-GREEN', 0, 1),
(6, 2, 1, 'Monte Carlo Turquoise Blue Solid Collar T Shirt', 1999, 1500, 10, '931830512__8-(1)-E5x-104831-NJD.jpg', 'lacus quis urna tristique suscipit. Praesent vitae mi mollis dui facilisis convallis eu faucibus augue.', 'Duis in risus quis lectus dictum fringilla. Aenean tempor pellentesque velit id ullamcorper. Ut id aliquam odio. Morbi id pharetra libero, ut tempor nisi. Maecenas a lectus nec risus maximus rutrum. Mauris vel elit ut magna semper laoreet nec sed magna. Quisque eleifend vel sem non malesuada. Interdum et malesuada fames ac ante ipsum primis in faucibus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vestibulum eget posuere orci, eu ultrices sapien. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aliquam sit amet ex dictum nisl bibendum elementum non in turpis. In bibendum ipsum nunc, bibendum lacinia lacus maximus eu. Interdum et malesuada fames ac ante ipsum primis in faucibus. Vivamus aliquam lacus quis urna tristique suscipit. Praesent vitae mi mollis dui facilisis convallis eu faucibus augue.', 0, 'Monte Carlo Turquoise Blue Solid Collar T Shirt', 'Monte Carlo Turquoise Blue Solid Collar T Shirt', 'Monte Carlo Turquoise Blue Solid Collar T Shirt', 0, 1),
(7, 4, 3, 'Floral Print Polo T-shirt', 1900, 1350, 7, '309027777_Floral-Print-Polo-T-shirt.jpg', 'isl pharetra orci, at condimentum nisl lorem elementum ipsum.', 'Nunc auctor turpis ante, eget bibendum mi mollis in. Aliquam quis neque ut libero malesuada auctor. Aliquam interdum enim at commodo gravida. Donec nisl sem, molestie ut quam quis, vulputate venenatis ipsum. Aenean quis ex ut magna accumsan fringilla. Quisque id ex massa. Sed libero ante, fringilla ac condimentum in, porttitor ac risus. Integer mattis odio nec nunc semper imperdiet. In porttitor tellus eget sapien vulputate, eu euismod lacus aliquet. Maecenas molestie elit augue, sit amet fringilla dolor congue et. Nunc eu libero auctor, sollicitudin lectus quis, porta ligula. In vel ullamcorper risus. Nullam viverra, mi sit amet laoreet luctus, urna nisl pharetra orci, at condimentum nisl lorem elementum ipsum.', 0, 'Floral Print Polo T-shirt', 'Floral Print Polo T-shirt', 'Floral Print Polo T-shirt', 0, 1),
(8, 4, 3, 'Floral Embroidered Polo T-shirt', 1900, 1120, 10, '651584201_Floral-Embroidered-Polo-T-shirt.jpg', 'rius, lacus velit aliquam ex, in dignissim sem eros ac erat. Vestibulum ac arcu tortor.', 'Vestibulum in auctor turpis. Quisque hendrerit eget turpis et molestie. Phasellus nec nibh a lacus rhoncus eleifend. Donec suscipit id diam non mattis. Fusce eu luctus leo. Etiam eget dui libero. Etiam eros lorem, rhoncus et convallis eget, tempus vel tellus. Nam at diam quis nisl tincidunt aliquam. Quisque placerat magna non libero interdum varius vel id risus. Vivamus mollis maximus fermentum. Donec eget nulla dui. Sed ultricies malesuada metus, non feugiat purus fringilla ac. Interdum et malesuada fames ac ante ipsum primis in faucibus. Integer accumsan, tortor id eleifend varius, lacus velit aliquam ex, in dignissim sem eros ac erat. Vestibulum ac arcu tortor.', 1, 'Floral Embroidered Polo T-shirt', '', 'Floral Embroidered Polo T-shirt', 0, 1),
(9, 4, 0, 'Floral Print Polo T-shirt Latest', 1560, 650, 10, '526258680_Floral-Print-Polo-T-shirt1.jpg', 's mus. Vestibulum eget posuere orci, eu ultrices sapien. Orc', 'aximus rutrum. Mauris vel elit ut magna semper laoreet nec sed magna. Quisque eleifend vel sem non malesuada. Interdum et malesuada fames ac ante ipsum primis in faucibus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vestibulum eget posuere orci, eu ultrices sapien. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aliquam sit amet ex d', 1, 'Floral Print Polo T-shirt Latest', '', 'Floral Print Polo T-shirt Latest', 0, 1),
(10, 4, 3, 'test', 100, 10, 1, '977077907_651584201_Floral-Embroidered-Polo-T-shirt.jpg', 'test', 'test', 0, '', '', '', 0, 1),
(26, 2, 1, 'tst', 0, 0, 0, '570414904_Screenshot (181).png', 'some', 'fed', 0, 'sdf', 'sdf', 'sd', 1, 1),
(27, 2, 1, 'tsting some', 0, 0, 0, '270710349_Screenshot (181).png', 'some', 'fed', 0, 'sdf', 'sdf', 'sd', 1, 1),
(28, 2, 1, 'Sai Shrestha testing', 0, 0, 0, '610990217_banner.jpg', 'short descrition', 'description', 0, 'met atitle', 'meta adecription', 'meta keyowrd', 1, 1),
(31, 2, 1, 'some prod', 0, 0, 0, '689979234_Screenshot (251).png', 'desc', 'test', 0, 'test', 'test', 'test', 1, 1),
(32, 1, 0, 'iphone', 0, 0, 0, '218277451_banner.jpg', 'good phone', 'good phone description', 0, 'meta title for iphone', 'meta decription for iphone', 'for better SEO', 1, 1),
(33, 2, 1, 'Esentials', 0, 0, 0, '189194043_Screenshot (180).png', 'short description', 'descripion', 1, 'meta ttile', 'meta description', 'meta keytword', 6, 1);

-- --------------------------------------------------------

--
-- Table structure for table `product_attributes`
--

CREATE TABLE `product_attributes` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `size_id` int(11) NOT NULL,
  `color_id` int(11) NOT NULL,
  `mrp` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_attributes`
--

INSERT INTO `product_attributes` (`id`, `product_id`, `size_id`, `color_id`, `mrp`, `price`, `qty`) VALUES
(1, 8, 5, 3, 1900, 1120, 10),
(2, 8, 4, 5, 1900, 1120, 8),
(3, 8, 2, 3, 1900, 1120, 9),
(4, 8, 4, 3, 1800, 1050, 4),
(5, 7, 0, 3, 1900, 1350, 10),
(6, 7, 0, 5, 1900, 1350, 8),
(7, 7, 0, 4, 1900, 1350, 6),
(8, 6, 5, 0, 1999, 1500, 10),
(9, 6, 4, 0, 1989, 1490, 9),
(10, 5, 0, 0, 2799, 2399, 10),
(11, 18, 5, 3, 15000, 2000, 30),
(12, 19, 4, 3, 15000, 10001, 2),
(13, 20, 5, 3, 1200, 10001, 2),
(14, 21, 5, 3, 15000, 10001, 2),
(15, 25, 5, 3, 1200, 2000, 2),
(16, 27, 5, 3, 15000, 10001, 2),
(17, 28, 5, 3, 15000, 10001, 2),
(18, 31, 5, 3, 15000, 10001, 20),
(19, 32, 0, 0, 15000, 20000, 30),
(20, 33, 4, 3, 2500, 2000, 1993);

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_images` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `product_id`, `product_images`) VALUES
(1, 8, '479197953_526258680_Floral-Print-Polo-T-shirt1.jpg'),
(2, 8, '301120849_309027777_Floral-Print-Polo-T-shirt.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `product_review`
--

CREATE TABLE `product_review` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rating` varchar(20) NOT NULL,
  `review` text NOT NULL,
  `status` int(11) NOT NULL,
  `added_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `shiprocket_token`
--

CREATE TABLE `shiprocket_token` (
  `id` int(11) NOT NULL,
  `token` varchar(500) NOT NULL,
  `added_on` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shiprocket_token`
--

INSERT INTO `shiprocket_token` (`id`, `token`, `added_on`) VALUES
(1, '', '2019-04-09 00:28:23');

-- --------------------------------------------------------

--
-- Table structure for table `size_master`
--

CREATE TABLE `size_master` (
  `id` int(11) NOT NULL,
  `size` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `order_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `size_master`
--

INSERT INTO `size_master` (`id`, `size`, `status`, `order_by`) VALUES
(1, 'X', 1, 3),
(2, 'XL', 1, 4),
(4, 'M', 1, 2),
(5, 'S', 1, 1),
(6, 'XXL', 1, 5);

-- --------------------------------------------------------

--
-- Table structure for table `sub_categories`
--

CREATE TABLE `sub_categories` (
  `id` int(11) NOT NULL,
  `categories_id` int(11) NOT NULL,
  `sub_categories` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_categories`
--

INSERT INTO `sub_categories` (`id`, `categories_id`, `sub_categories`, `status`) VALUES
(1, 2, 'T-Shirt', 1),
(2, 2, 'Trouser', 1),
(3, 4, 'Shirt', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `added_on` datetime NOT NULL,
  `verify_status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `password`, `email`, `mobile`, `added_on`, `verify_status`) VALUES
(1, 'Vishal Gupta', 'vishal', 'ytlearnwebdevelopment@gmail.com', '1234567890', '2020-05-13 00:00:00', 0),
(2, 'Amit', 'amit', 'amir@gmail.com', '1234567890', '2020-05-14 00:00:00', 1),
(3, 'Vishal', '123', 'aa@gmail.com', '9540608104', '2021-04-15 03:32:06', 0),
(4, 'Sai Shrestha`', 'admin123!', 'admin@admin.com', '9861967556', '2023-03-31 11:37:25', 1),
(5, 'T3seting', 'Admin123@$', 'testadmin@admin.com', '9864545645', '2023-04-08 08:18:14', 0),
(6, 'T3seting', 'Admin123@$', 'testadmin123@admin.com', '9864545649', '2023-04-08 08:22:52', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `added_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`id`, `user_id`, `product_id`, `added_on`) VALUES
(1, 1, 12, '2021-04-08 01:53:31'),
(2, 2, 5, '2023-03-23 04:40:24'),
(3, 2, 31, '2023-03-26 06:44:28'),
(4, 2, 32, '2023-03-30 10:24:32'),
(5, 4, 32, '2023-03-31 01:10:52');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `color_master`
--
ALTER TABLE `color_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conversations`
--
ALTER TABLE `conversations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coupon_master`
--
ALTER TABLE `coupon_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `negotiations`
--
ALTER TABLE `negotiations`
  ADD PRIMARY KEY (`negotation_id`);

--
-- Indexes for table `negotiation_price`
--
ALTER TABLE `negotiation_price`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_status`
--
ALTER TABLE `order_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_attributes`
--
ALTER TABLE `product_attributes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_review`
--
ALTER TABLE `product_review`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shiprocket_token`
--
ALTER TABLE `shiprocket_token`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `size_master`
--
ALTER TABLE `size_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `color_master`
--
ALTER TABLE `color_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `conversations`
--
ALTER TABLE `conversations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `coupon_master`
--
ALTER TABLE `coupon_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `negotiations`
--
ALTER TABLE `negotiations`
  MODIFY `negotation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `negotiation_price`
--
ALTER TABLE `negotiation_price`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `order_detail`
--
ALTER TABLE `order_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `order_status`
--
ALTER TABLE `order_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `product_attributes`
--
ALTER TABLE `product_attributes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `product_review`
--
ALTER TABLE `product_review`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `shiprocket_token`
--
ALTER TABLE `shiprocket_token`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `size_master`
--
ALTER TABLE `size_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sub_categories`
--
ALTER TABLE `sub_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
