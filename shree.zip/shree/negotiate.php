<?php
require('db_connection.inc.php');
require('functions.inc.php'); 
session_start();

class Negotiate{
	function __construct()
	{
		$this->con=mysqli_connect("localhost","root","","ghatau");
	} 
	// User Type 0 => Customer , 1 => Vendor
	function addCustomer($product_id,$value){
		$user_id = $_SESSION['USER_ID']; 
		$user_type = 0;
	

		$get_sql = "Select * from negotiations where customer_id = '$user_id' and product_id = '$product_id'";
		$check_res=mysqli_query($this->con,$get_sql);
		// return $get_sql;  
		if(mysqli_num_rows($check_res) > 0){
			$test_row=mysqli_fetch_assoc($check_res);
			// return $test_row;/
			$negotiate_id=$test_row['negotation_id'];
			
			$update_sql = "UPDATE negotiations SET accept_status='1' WHERE negotation_id = '$negotiate_id'";
			$res=mysqli_query($this->con,$update_sql); 
			
			$sql = "UPDATE negotiation_price SET active_status='0' WHERE negotiate_id = '$negotiate_id'";
			$res=mysqli_query($this->con,$sql); 

			$insert_price_sql = "INSERT into negotiation_price(negotiate_id , price , user_id , user_type , active_status) values('$negotiate_id', '$value' , '$user_id' , '$user_type','1')";
			$result_neg = mysqli_query($this->con,$insert_price_sql); 

			if ($result_neg == TRUE) {
				return ['status'=> 202, 'message'=> 'Vendor has accepted and Order placed'];
			}else {
				return ['status'=> 303, 'message'=> 'Operation Failed'];
		}	
		}else{
			$insert_sql = "INSERT into negotiations(product_id , customer_id , accept_status) values('$product_id', '$user_id' ,'1')";
			$result = mysqli_query($this->con,$insert_sql);
			$negotiate_id=mysqli_insert_id($this->con);
 

			$insert_price_sql = "INSERT into negotiation_price(negotiate_id , price , user_id , user_type , active_status) values('$negotiate_id', '$value' , '$user_id' , '$user_type','1')";
			$result_neg = mysqli_query($this->con,$insert_price_sql); 

			if ($result_neg == TRUE) {
				return ['status'=> 202, 'message'=> 'Vendor has accepted and Order placed'];
			}else {
				return ['status'=> 303, 'message'=> 'Operation Failed'];
			}	
			

		}
		
	}
	
 
}

$type=get_safe_value($con,$_POST['type']);

$obj=new Negotiate();

if($type=='add_customer'){ 
	$product_id=get_safe_value($con,$_POST['product_id']);
	$value=get_safe_value($con,$_POST['value']);
	echo json_encode($obj->addCustomer($product_id,$value));
	exit();	
}
 
 
?>