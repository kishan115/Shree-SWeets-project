<?php
require('connection.inc.php');
require('functions.inc.php');

$value=get_safe_value($con,$_POST['value']); 
$user_id = $_SESSION['USER_ID'];

// update user verify status
$update_user = "UPDATE users SET verify_status='$value' WHERE id = '$user_id'";
$update_res=mysqli_query($con,$update_user); 

// return 0( if unsucessfull ) or 1( if success)
 echo $update_res;
?>