<?php
session_start();

/**
 * 
 */
class Message
{
	
	private $con;

	function __construct()
	{
        $this->con=mysqli_connect("localhost","root","","ghatau");
	} 

	// Get the response of a query by using like query. 
	public function add_customer_chat($text , $sender , $receiver){ 
		$sql = "SELECT * FROM conversations WHERE account_sender_id =  $sender and account_receiver_id = $receiver";
		$query = $this->con->query($sql);
		
			// encrypt chat
			$ciphering_value = "AES-128-CTR";   
			// Store the encryption key  
			$encryption_key = "ghatau";  
			// Use openssl_encrypt() function   
			$encryption_value = openssl_encrypt($text, $ciphering_value, $encryption_key);   
			  
		if ($query->num_rows > 0) {   
			$result = $query->fetch_assoc();
            $conversation_id = $result['id'];
			

            $sql = "INSERT INTO messages(conversation_id ,  account_id , msg) VALUES ('$conversation_id' ,'$sender' ,'$encryption_value')";
            $query = $this->con->query($sql); 
            if($query == TRUE){ 
                return ['status'=> 202, 'message'=> 'Inserted successfully'];
            }else {
                return ['status'=> 303, 'message'=> 'Insertion Failed'];
            }
                
		}else {
            $sql = "INSERT INTO conversations(account_sender_id , account_receiver_id) VALUES ('$sender' ,'$receiver')";
            $query = $this->con->query($sql); 		
            if ($query == TRUE) { 
			    $conversation_id=mysqli_insert_id($this->con); 
                $sql = "INSERT INTO messages(conversation_id ,  account_id , msg) VALUES ('$conversation_id' ,'$sender' ,'$encryption_value')";
                $query = $this->con->query($sql); 
                return ['status'=> 202, 'message'=> 'Inserted successfully'];
            }else {
                return ['status'=> 303, 'message'=> 'Insertion Failed'];
            }

		}	
	} 

	// insert into messages
	public function view($sender , $receiver){  
		$sql = "SELECT * FROM conversations WHERE account_sender_id =  $sender and account_receiver_id = $receiver";
		$query = $this->con->query($sql); 


		if ($query->num_rows > 0) {   
			$result = $query->fetch_assoc();
			$id = $result['id'];
			
			$sql = "SELECT * FROM messages WHERE conversation_id = $id order by submit_date ASC";
			$query = $this->con->query($sql);
			$data = [];
			if ($query->num_rows > 0) {   
				$i = 0;
				while($row=mysqli_fetch_assoc($query)){
					array_push($data , $row);

					// decrypt chat
					$ciphering_value = "AES-128-CTR";   
					$decryption_key = "ghatau";  
					// Use openssl_decrypt() function to decrypt the data  
					$decryption_value = openssl_decrypt($row['msg'], $ciphering_value, $decryption_key);   

					$data[$i]['msg'] = $decryption_value;
					$i++;
				}  
				return ['status'=> 202, 'message'=> 'Record Found' , 'data' => $data]; 
			}else { 
				return ['status'=> 303, 'message'=> 'Operation Failed'];
			}
            
		}else {
            
			return ['status'=> 304, 'message'=> 'No conversation Found Failed']; 

		}	


		
	} 
 
} 
 
if (isset($_POST["add_customer_chat"])) {
	$text = $_POST['text'];
	$sender = $_POST['sender'];
	$receiver = $_POST['receiver'];
	$a = new Message(); 
	echo json_encode($a->add_customer_chat($text, $sender , $receiver));
	exit();	
}

// redirect to view function on ajax call
if (isset($_POST["view_chat"])) {
	$sender = $_POST['sender'];
	$receiver = $_POST['receiver'];
	$a = new Message(); 
	echo json_encode($a->view($sender , $receiver));
	exit();	
}
  
?>