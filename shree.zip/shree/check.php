<?php 
require('connection.inc.php');
require "Authenticator.php";
if ($_SERVER['REQUEST_METHOD'] != "POST") {
    header("location: login.php");
    die();
}
 
$user_id = $_SESSION['unverified_user_id'];
$Authenticator = new Authenticator();
$checkResult = $Authenticator->verifyCode($_SESSION['auth_secret'], $_POST['code'], 2);    // 2 = 2*30sec clock tolerance

if (!$checkResult) {
    echo json_encode(['verify_status' => 0]);
	exit();	
}else{
    // login users
    $res=mysqli_query($con,"select * from users where id='$user_id'"); 
    $row=mysqli_fetch_assoc($res); 
    $_SESSION['USER_LOGIN']='yes';
    $_SESSION['USER_ID']=$row['id'];
    $_SESSION['USER_NAME']=$row['name'];
    
    if(isset($_SESSION['WISHLIST_ID']) && $_SESSION['WISHLIST_ID']!=''){
        wishlist_add($con,$_SESSION['USER_ID'],$_SESSION['WISHLIST_ID']);
        unset($_SESSION['WISHLIST_ID']);
        unset($_SESSION['unverified_user_id']);
    } 

    echo json_encode(['verify_status' => 1]);
	exit();	
} 
?>