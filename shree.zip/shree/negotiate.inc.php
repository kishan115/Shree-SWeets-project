<?php
session_start();
// require('db_connection.inc.php');


?>