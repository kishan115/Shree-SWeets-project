<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
<!-- css for chat box  -->
<style>
   @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');

    ::-webkit-scrollbar{
        width: 3px;
        border-radius: 25px;
    }
    ::-webkit-scrollbar-track{
        background: #f1f1f1;
    }
    ::-webkit-scrollbar-thumb{
        background: #ddd;
    }
    ::-webkit-scrollbar-thumb:hover{
        background: #ccc;
    }
.wrapper .title{
        background: #007bff;
        color: #fff;
        font-size: 20px;
        font-weight: 500;
        line-height: 60px;
        text-align: center;
        border-bottom: 1px solid #006fe6;
        border-radius: 5px 5px 0 0;
    }
    .wrapper .form{
        padding: 20px 15px;
        min-height: 400px;
        max-height: 400px;
        overflow-y: auto;
    }
    .wrapper .form .inbox{
        width: 100%;
        display: flex;
        align-items: baseline;
    }
    .wrapper .form .user-inbox{
        justify-content: flex-end;
        margin: 13px 0;
    }
    .wrapper .form .inbox .icon{
        height: 40px;
        width: 40px;
        color: #fff;
        text-align: center;
        line-height: 40px;
        border-radius: 50%;
        font-size: 18px;
        background: #007bff;
    }
    .wrapper .form .inbox .msg-header{
        max-width: 53%;
        margin-left: 10px;
    }
    .form .inbox .msg-header p{
        color: #fff;
        background: #007bff;
        border-radius: 10px;
        padding: 8px 10px;
        font-size: 14px;
        word-break: break-all;
    }
    .form .user-inbox .msg-header p{
        color: #333;
        background: #efefef;
    }
    .wrapper .typing-field{
        display: flex;
        height: 60px;
        width: 100%;
        align-items: center;
        justify-content: space-evenly;
        background: #efefef;
        border-top: 1px solid #d9d9d9;
        border-radius: 0 0 5px 5px;
    }
    .wrapper .typing-field .input-data{
        height: 40px;
        width: 335px;
        position: relative;
    }
    .wrapper .typing-field .input-data input{
        height: 100%;
        width: 100%;
        outline: none;
        border: 1px solid transparent;
        padding: 0 80px 0 15px;
        border-radius: 3px;
        font-size: 15px;
        background: #fff;
        transition: all 0.3s ease;
    }
    .typing-field .input-data input:focus{
        border-color: rgba(0,123,255,0.8);
    }
    .input-data input::placeholder{
        color: #999999;
        transition: all 0.3s ease;
    }
    .input-data input:focus::placeholder{
        color: #bfbfbf;
    }
    .wrapper .typing-field .input-data button{
        position: absolute;
        right: 5px;
        top: 50%;
        height: 30px;
        width: 65px;
        color: #fff;
        font-size: 16px;
        cursor: pointer;
        outline: none;
        opacity: 0;
        pointer-events: none;
        border-radius: 3px;
        background: #007bff;
        border: 1px solid #007bff;
        transform: translateY(-50%);
        transition: all 0.3s ease;
    }
    .wrapper .typing-field .input-data input:valid ~ button{
        opacity: 1;
        pointer-events: auto;
    }
    .typing-field .input-data button:hover{
        background: #006fef;
    }
</style>

    <div class="pull-right"> 
        <button id='togglechat' class="btn btn-sm btn-primary">------------------------------------------------------------------------------------Chat with vendor-----------------------------------------------------------------------</button>
    </div>
       <br><br> 
    </div>

	<?php
 		if(isset($_SESSION['USER_ID'])){
			$user_id = $_SESSION['USER_ID']; 
		}else{
			$user_id ='';
		} 
		$vendor_id = $get_product['0']['added_by']; 
	?>	
    <div class="wrapper sidebar" id='sidebar_chat'>
        <div class="title">Chat with the vendor</div>
        <!-- values are added in htis div-->
        <div class="form" id='chat_form'></div>
        <div class="typing-field">
            <div class="input-data">
                <input id="data" type="text" placeholder="Type something here.." required>
				<input type="hidden" id="sender" value=<?= $user_id ?>>
				<input type="hidden" id="receiver" value=<?= $vendor_id ?>>
                <button id="send-btn">Send</button>
            </div>
        </div>	
    </div>
    <script>
        $(document).ready(function(){    
            $("#sidebar_chat").hide(); 


            function viewChat(){
                var sender = $("#sender").val();
                    var receiver = $("#receiver").val();
                    // start ajax code
                    $('#chat_form').empty();
                    $.ajax({
                        url: 'Message.php',
                        type: 'POST',
                        data: { sender : sender , receiver : receiver , view_chat : 1 }, 
                        success: function(msg){

                            var result = $.parseJSON(msg);
                            console.log(result);
                            if (result.status == 202) {
                                console.log(result.data);
                                var i = 0;
                                var reply ='';
                                $.each(result.data, function(index, value) { 
                                    console.log(value['account_id']);
                                    if ( sender  == value['account_id'] ){
                                        reply += '<div class="user-inbox inbox"><div class="icon"><i class="fas fa-user"></i></div><div class="msg-header"><p>'+ value['msg'] +'</p></div></div>'; 
                                    }else{
                                        reply += '<div class="bot-inbox inbox"><div class="icon"><i class="fas fa-user"></i></div><div class="msg-header"><p>'+ value['msg'] +'</p></div></div>';
                                    }
                                }); 
                                $("#chat_form").append(reply);

                            } else {
                                alert(result.message);
                            }
                        }
                    });
            }
            
            $("#togglechat").on("click",function(){
                if ($('#sidebar_chat').css('display') == 'none') {                    
                    $("#sidebar_chat").show();


                    var sender = $("#sender").val();
                    var receiver = $("#receiver").val();
                    // start ajax code
                    $('#chat_form').empty();
                    $.ajax({
                        url: 'Message.php',
                        type: 'POST',
                        data: { sender : sender , receiver : receiver , view_chat : 1 }, 
                        success: function(msg){

                            var result = $.parseJSON(msg);
                            console.log(result);
                            if (result.status == 202) {
                                console.log(result.data);
                                var i = 0;
                                var reply ='';
                                $.each(result.data, function(index, value) { 
                                    console.log(value['account_id']);
                                    if ( sender  == value['account_id'] ){
                                        reply += '<div class="user-inbox inbox"><div class="icon"><i class="fas fa-user"></i></div><div class="msg-header"><p>'+ value['msg'] +'</p></div></div>'; 
                                    }else{
                                        reply += '<div class="bot-inbox inbox"><div class="icon"><i class="fas fa-user"></i></div><div class="msg-header"><p>'+ value['msg'] +'</p></div></div>';
                                    }
                                }); 
                                $("#chat_form").append(reply);
                                view_Interval = setInterval(viewChat, 5000); 

                            } else if(result.status == 304) {

                                reply = '<div class="bot-inbox inbox"><div class="icon"><i class="fa fa-user"></i></div><div class="msg-header"><p>Hello there, how can I help you?</p></div></div>'
                                $("#chat_form").append(reply); 
                            }else{
                                alert(result.message);
                            }
                        }
                    });


                }else{                    
                    $("#sidebar_chat").hide();
		            clearInterval(view_Interval);
                }
            })

            $("#send-btn").on("click", function(){
                var value = $("#data").val();
                var sender = $("#sender").val();
                var receiver = $("#receiver").val();
				
                var msg = '<div class="user-inbox inbox"><div class="msg-header"><p>'+ value +'</p></div></div>';
                $("#chat_form").append(msg);
                $("#data").val('');
                
                // start ajax code
                $.ajax({
                    url: 'Message.php',
                    type: 'POST',
                    data: {text : value , sender : sender , receiver : receiver , add_customer_chat : 1 }, 
                    success: function(result){
                        console.log(result);
                        view_Interval = setInterval(viewChat, 5000); 
                    }
                });
            });
        });
    </script>