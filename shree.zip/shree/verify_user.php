<?php 
require('top.php');
require "Authenticator.php";
$Authenticator = new Authenticator();
if (!isset($_SESSION['auth_secret'])) {
    $secret = $Authenticator->generateRandomSecret();
    $_SESSION['auth_secret'] = $secret;
}
$qrCodeUrl = $Authenticator->getQR('myPHPnotes', $_SESSION['auth_secret']);

if (!isset($_SESSION['failed'])) {
    $_SESSION['failed'] = false;
}
 
?>

<!-- Start Bradcaump area -->
        <div class="ht__bradcaump__area" style="background: rgba(0, 0, 0, 0) url(images/bg/4.jpg) no-repeat scroll center center / cover ;">
            <div class="ht__bradcaump__wrap">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="bradcaump__inner">
                                <nav class="bradcaump-inner">
                                  <a class="breadcrumb-item" href="index.php">Home</a>
                                  <span class="brd-separetor"><i class="zmdi zmdi-chevron-right"></i></span>
                                  <span class="breadcrumb-item active">Veriy User</span>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Bradcaump area -->		
               
		<!-- Start Contact Area -->
        <section class="htc__contact__area ptb--100 bg__white">
            <div class="container">
                <div class="row">
					<div class="col-md-6">
						<br><hr>
						<div class="row">
							<label> Please Scan and verify yourself</label>
							<div class="col-md-6">
								<img style="text-align: center;;" class="img-fluid" src="<?php   echo $qrCodeUrl ?>" alt="Verify this Google Authenticator">
							</div>
							<div class="col-md-6">
								<input type="text" class="form-control" name="code" id='verify_code' placeholder="******" style="font-size: xx-large;width: 200px;border-radius: 0px;text-align: center;display: inline;color: #0275d8;"><br> <br>    
								<button id="verify" class="btn btn-md btn-primary" style="width: 200px;border-radius: 0px;">Verify</button>
							</div>
						</div>
						<div class="alert alert-danger" role="alert" id='validity_code_failed'>
							<strong>Oh snap!</strong> Invalid Code.
						</div>
						<div class="alert alert-success" role="alert" id='validity_code_success'>
							<strong>Validated Successfully.</strong>
						</div>
						<hr>   
					</div> 
				</div>  
			</div>
        </section> 
<?php require('footer.php')?>  

<script> 
	$(document).ready(function() { 
		$('#validity_code_failed').hide();
		$('#validity_code_success').hide();
	});	
	
	$("#verify").click(function(event)
	{ 	
		event.preventDefault();	
		var verify_code = $('#verify_code').val();
		$.ajax({
			url:'check.php',
			type:'POST',
			data: {code : verify_code},
			error :function(xhr, ajaxOptions, thrownError)
			{
				console.log(xhr);
				console.log(ajaxOptions);
				console.log(thrownError);
			},
			success:function(msg)
			{	
				var result = $.parseJSON(msg);
				console.log(result.verify_status);
				if(result.verify_status == 1){ 
					$('#validity_code_success').show();
					$('#validity_code_failed').hide();
					window.location.href='index.php';
				}else
				{ 
					$('#validity_code_failed').show();
					$('#validity_code_success').hide();
				}  
			} 
		}); 
	});
</script>      