<?php
require('connection.inc.php');
require('functions.inc.php');

$name=get_safe_value($con,$_POST['name']);
$email=get_safe_value($con,$_POST['email']);
$mobile=get_safe_value($con,$_POST['mobile']);
$password=get_safe_value($con,$_POST['password']);
$g_recaptcha_response=get_safe_value($con,$_POST['g_recaptcha_response']);



if(isset($_POST['g_recaptcha_response'])){
	$secretkey = '6LfQfo0lAAAAAGCp8PzuU9ISYmBkzAt9RyDAEStb';
	$ip = $_SERVER['REMOTE_ADDR'];
	$response = $_POST['g_recaptcha_response'];
	$url = 'https://www.google.com/recaptcha/api/siteverify?secret='.$secretkey.'&response='.$response.'&remoteip='.$ip;
	$file = file_get_contents($url);
	$data = json_decode(($file));

	// echo $data->success;
	if($data->success == true){
		$check_user=mysqli_num_rows(mysqli_query($con,"select * from users where email='$email'"));
		$check_mobile=mysqli_num_rows(mysqli_query($con,"select * from users where mobile='$mobile'"));
		if($check_user>0){
			echo "email_present";
		}elseif($check_mobile>0){
			echo "mobile_present";
		}else{
			$added_on=date('Y-m-d h:i:s');
			mysqli_query($con,"insert into users(name,email,mobile,password,added_on,verify_status) values('$name','$email','$mobile','$password','$added_on', 1)");
			echo "insert";
		}
	}else{
		echo $data->success;
		// echo "Recaptcha Validation Error";
	}
}else{
	echo "Please fill Recaptcha";
}


?>